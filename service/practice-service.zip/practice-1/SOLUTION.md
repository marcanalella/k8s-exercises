Service Practice
================

1) create a deployment using nginx image
2) create a service to expose nginx deployment

``kubectl apply -f solution_1.yaml``

3) open your favourite browser and go to the cluster ip (localhost on windows, minikube ip on unix) and port to see nginx response


Docker Desktop (Windows / Mac)

``curl localhost:$NODE_PORT``


Docker Desktop (Minikube on Ubuntu)

``curl $MINIKUE_IP:$NODE_PORT``